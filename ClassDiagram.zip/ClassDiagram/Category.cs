﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassDiagram
{
    internal class Category
    {
        [Required]
        public string VehicleType { get; set; }
        //public int Seat_capacity { get; set; }
    }
}
