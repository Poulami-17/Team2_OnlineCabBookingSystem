﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassDiagram
{
    internal class Driver : User
    {
        [Required]
        [RegularExpression(@"^[A-Z]{2}\d{2} [A-Z]{2}\d{4}$", ErrorMessage = "Invalid license number format")]
        public string LicenseNo { get; set; }

        [Required]
        public string VehicleId {  get; set; }

        [RegularExpression("^(Free|Busy)$", ErrorMessage = "Status must be one of: Free and Busy")]
        public bool AvailabilityStatus { get; set; }

        [Required]
        public float AvgRating { get; set; }

        public int TotalTrips {  get; set; }

        [Required]
        [RegularExpression("[A-Z]{4} [0-9]{4}",ErrorMessage ="Invalid PanNo")]
        public string PanNo { get; set; }

        [Required]
        [RegularExpression("[A-Z]{4} [0-9]{4}", ErrorMessage = "Invalid AadharNo")]
        public long AadharNo { get; set; }



     

    }
}
