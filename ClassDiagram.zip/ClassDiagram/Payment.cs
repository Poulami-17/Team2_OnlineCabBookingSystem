﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//enum method { cash , upi }

namespace ClassDiagram
{
    internal class Payment : BaseObject
    {
        [Required]
        public float Amount { get; set; }

        [Required]
        public string PaymentMethod { get; set; }

        [Required]
        public string TransactionID {  get; set; }
    }
}
