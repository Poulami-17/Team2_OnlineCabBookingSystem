﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace ClassDiagram
{
    internal class Booking : BaseObject
    {
        [JsonIgnore]
        public Customer Customer { get; set; }

        [JsonIgnore]
        public Driver Driver { get; set; }

        [JsonIgnore]
        public Payment Payment { get; set; }

        [Required]
        [StringLength(200)]
        public string Pickup { get; set; }

        [Required]
        [StringLength(200)]
        public string Destination { get; set; }
        //public DateTime Date_time { get; set; }

        [Required]
        public float Fare { get; set; }
        public float Distance { get; set; }
        public string Cancellation { get; set; }
        public bool BookingStatus { get; set; }

    }
}
