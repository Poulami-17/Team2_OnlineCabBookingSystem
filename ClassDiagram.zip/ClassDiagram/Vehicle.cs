﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassDiagram
{
    internal class Vehicle : BaseObject
    {
        [Required]
        public string VehicleNo { get; set; }

        [Required]
        public string Brand { get; set; }

        [Required]
        public string Color { get; set; }

        [Required]
        public string Type { get; set; }

        [RegularExpression("^(Free|Busy)$", ErrorMessage = "Status must be one of: Free and Busy")]
        public bool AvailabilityStatus { get; set; }

        [Required]
        public Category Category;
    }
}
